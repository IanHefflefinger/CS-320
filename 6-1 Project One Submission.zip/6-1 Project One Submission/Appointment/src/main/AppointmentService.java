package main;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AppointmentService {
	private static List<Appointment> appointments = new ArrayList<Appointment>();
	
	// this class will check to make sure id's are unique but will not generate unique id's - this responsibility lies with the user/tester
	public static List<String> idList = new ArrayList<String>();
	
	// create appointment
	public static void addAppointment(Object appointment) {
		// add appointment to list
		appointments.add((Appointment) appointment);
		// check if appointment id is unique
		for (int i = 0; i < idList.size(); i++) {
			if (((Appointment) appointment).getAppointmentId().equals(idList.get(i))) {
				throw new IllegalArgumentException("Not a unique ID!");
			}
		}
		// else, add id to public idList
		idList.add(((Appointment) appointment).getAppointmentId());
	}
	
	// read appointment - check appointment exists
	public static boolean appointmentExists(String appointmentId) {
		// iterate through list
		for (int i = 0; i < appointments.size(); i++) {
			if (appointments.get(i).getAppointmentId().equals(appointmentId)) {
				return true;
			}
		}
		return false;
	}
	
	// read appointment - check appointment variables equal to parameters
	public static Object readAppointment(String appointmentId) {
		for (int i = 0; i < appointments.size(); i++) {
			if (appointments.get(i).getAppointmentId().equals(appointmentId)) {
				return appointments.get(i);
			}
		}
		throw new IllegalArgumentException("Appointment not found");
	}
	
	// update appointment
	public static void updateAppointment(String appointmentId, Date appointmentDate, String appointmentDescription) {
		// iterate through appointment until appointment in question is found
		for (int i = 0; i < appointments.size(); i++) {
			if (appointments.get(i).getAppointmentId().equals(appointmentId)) {
				appointments.get(i).setAppointmentDate(appointmentDate);
				appointments.get(i).setAppointmentDescription(appointmentDescription);
			}
		}
	}
	
	// delete appointment
	public static void deleteAppointment(String appointmentId) {
		// iterate through list
		for (int i = 0; i < appointments.size(); i++) {
			if (appointments.get(i).getAppointmentId().equals(appointmentId)) {
				appointments.remove(i);
			}
		}
	}
}
