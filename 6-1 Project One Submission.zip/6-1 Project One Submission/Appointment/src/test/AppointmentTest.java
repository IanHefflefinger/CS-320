package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import main.Appointment;

import java.util.Date;
import java.io.*;

class AppointmentTest { 

	@Test
	void testIdNull() {
		Date date = new Date();
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment(null, date, "A whole bunch of stuff and things");
		});
	}
	
	@Test
	void testIdTooLong() {
		Date date = new Date();
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment("12345678910", date, "A whole bunch of stuff and things");
		});
	}
	
	@Test
	void testDateNull() {
		Date date = new Date();
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment("123456789", null, "A whole bunch of stuff and things");
		});
	}
	
	@Test
	void testDateInPast() throws InterruptedException {
		Date date = new Date();
		//Pause for 1 second - system is really fast and will usually assume the times being compared are the same
        Thread.sleep(1000);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment("123456789", date, "A whole bunch of stuff and things");
		});
	}
	
	@Test
	void testDescriptionNull() {
		Date date = new Date();
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment("123456789", date, null);
		});
	}
	
	@Test
	void testDescriptionTooLong() {
		Date date = new Date();
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment("12345678910", date, "A description that is clearly way too long to pass the reqs I set within the Appointment.java file. The weather is ok today - not too cloudy. I think I'll go skiing later.");
		});
	}

}
