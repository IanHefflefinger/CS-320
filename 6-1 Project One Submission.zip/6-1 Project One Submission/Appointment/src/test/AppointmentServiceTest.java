package test;

import main.Appointment;
import main.AppointmentService;

import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {
	@Test
	public void testUniqueId() {
		// create date in the future
		@SuppressWarnings("deprecation")
		Date date = new Date(124, 2, 06, 14, 28, 36); // date set in future to avoid errors
		// create and add a appointment
		Appointment newAppointment = new Appointment("1", date, "Appointment description");
		AppointmentService.addAppointment(newAppointment);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			// create a new appointment with the SAME id and try to add
			Appointment newerAppointment = new Appointment("1", date, "Appointment has an id that has already been used");
			AppointmentService.addAppointment(newerAppointment);
		});
	}
	
	@Test
	public void testAddAppointment() {
		// create date in the future
		@SuppressWarnings("deprecation")
		Date date = new Date(124, 2, 06, 14, 28, 36); // date set in future to avoid errors
		// create and add a appointment
		Appointment newAppointment = new Appointment("2", date, "Appointment description");
		AppointmentService.addAppointment(newAppointment);
		// verify appointment exists
		Assertions.assertTrue(AppointmentService.appointmentExists("2")); 
	}
	
	@Test
	public void testDeleteAppointment() {
		// create date in the future
		@SuppressWarnings("deprecation")
		Date date = new Date(124, 2, 06, 14, 28, 36); // date set in future to avoid errors
		// create and add a appointment
		Appointment newAppointment = new Appointment("3", date, "Appointment description");
		AppointmentService.addAppointment(newAppointment);
		AppointmentService.deleteAppointment("3");
		Assertions.assertFalse(AppointmentService.appointmentExists("3"));
	}
	
	@Test
	public void testUpdateAppointment() {
		// create date in the future
		@SuppressWarnings("deprecation")
		Date date = new Date(124, 2, 06, 14, 28, 36); // date set in future to avoid errors
		// create and add a appointment
		Appointment newAppointment = new Appointment("4", date, "Appointment description");
		AppointmentService.addAppointment(newAppointment);
		// update appointment
		// new date
		@SuppressWarnings("deprecation")
		Date newDate = new Date(127, 2, 06, 14, 28, 36); // date set in future to avoid errors
		AppointmentService.updateAppointment("4", newDate, "this appointment has been updated");
		// query appointment with above id
		Object compareMe = AppointmentService.readAppointment("4");
		// check updated appointment to ensure variables were updated as expected
		Assertions.assertTrue(
				((Appointment) compareMe).getAppointmentDate().equals(newDate) && ((Appointment) compareMe).getAppointmentDescription().equals("this appointment has been updated")
		);
	}
	
	@Test
	public void testReadAppointmentNotFound() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			AppointmentService.readAppointment("666");
		});
	} 
	
}