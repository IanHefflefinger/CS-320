package test;

import main.Task;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class TaskTest {
	@Test // test that task gets created successfully
	void testTask() {
		Task task = new Task("123", "Take out trash", "Ya garbage! And you'll never be nothing!");
		Assertions.assertTrue(task.getTaskId().equals("123"));
		Assertions.assertTrue(task.getTaskName().equals("Take out trash"));
		Assertions.assertTrue(task.getTaskDescription().equals("Ya garbage! And you'll never be nothing!"));
	}
	
	// test null exceptions
	@Test
	void testIdNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task(null, "Totally valid", "Perfectly normal and acceptable description.");
		});
	}
	
	@Test
	void testNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task("123", null, "Perfectly normal and acceptable description.");
		});
	}
	
	@Test
	void testDescriptionNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task("123", "Totally valid", null);
		});
	}
	
	// test parameters too long
	@Test
	void testIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task("12345678901", "Totally valid", "Perfectly normal and acceptable description.");
		});
	}
	@Test
	void testNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task("123", "This name is far too long as it is longer than 20 characters", "Perfectly normal and acceptable description.");
		});
	}
	
	@Test
	void testDescriptionTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task("12345678901", "Totally valid", "Alright, here we go. The description field can only be 50 characters long and this entry is clearly way too long. Just to be sure, I'll add this one last sentence.");
		});
	}
	
	// test setters
	@Test
	void testSetTaskName() {
		Task task = new Task("123", "Totally valid", "Perfectly normal and acceptable description.");
		task.setTaskName("This is ok");
		Assertions.assertTrue(task.getTaskName().equals("This is ok"));
	}
	
	@Test
	void testSetTaskDescription() {
		Task task = new Task("123", "Totally valid", "Perfectly normal and acceptable description.");
		task.setTaskDescription("This is also a totally normal and acceptable description. Except, this one is different, but that's ok.");
		Assertions.assertTrue(task.getTaskDescription().equals("This is also a totally normal and acceptable description. Except, this one is different, but that's ok."));
	}
}
