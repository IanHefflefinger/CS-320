package main;

import java.util.ArrayList;
import java.util.List;

public class TaskService {
	private static List<Task> tasks = new ArrayList<Task>();
	
	// this class will check to make sure id's are unique but will not generate unique id's - this responsibility lies with the user/tester
	public static List<String> idList = new ArrayList<String>();
	
	// create task
	public static void addTask(Object task) {
		// add task to list
		tasks.add((Task) task);
		// check if task id is unique
		for (int i = 0; i < idList.size(); i++) {
			if (((Task) task).getTaskId().equals(idList.get(i))) {
				throw new IllegalArgumentException("Not a unique ID!");
			}
		}
		// else, add id to public idList
		idList.add(((Task) task).getTaskId());
	}
	
	// read task - check task exists
	public static boolean taskExists(String taskId) {
		// iterate through list
		for (int i = 0; i < tasks.size(); i++) {
			if (tasks.get(i).getTaskId().equals(taskId)) {
				return true;
			}
		}
		return false;
	}
	
	// read task - check task variables equal to parameters
	public static Object readTask(String taskId) {
		for (int i = 0; i < tasks.size(); i++) {
			if (tasks.get(i).getTaskId().equals(taskId)) {
				return tasks.get(i);
			}
		}
		throw new IllegalArgumentException("Task not found");
	}
	
	// update task
	public static void updateTask(String taskId, String taskName, String taskDescription) {
		// iterate through task until task in question is found
		for (int i = 0; i < tasks.size(); i++) {
			if (tasks.get(i).getTaskId().equals(taskId)) {
				tasks.get(i).setTaskName(taskName);
				tasks.get(i).setTaskDescription(taskDescription);
			}
		}
	}
	
	// delete task
	public static void deleteTask(String taskId) {
		// iterate through list
		for (int i = 0; i < tasks.size(); i++) {
			if (tasks.get(i).getTaskId().equals(taskId)) {
				tasks.remove(i);
			}
		}
	}
}
