package test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import main.Contact;

class ContactTest {

	//@Test
	//public void setup() {
		//String str = "First Junit test";
		//assertEquals("First Junit test",str);
	//}
	
	@Test
	public void IdLongerThanTen() {
		Assertions.assertThrows(ArithmeticException.class, () -> {
			// throws exception because id is greater than 10 characters
			Contact newContact = new Contact("455678765456765578", "ian", "heff", "1234567890", "100 ave");
		});
	}
	
	@Test
	public void firstNameLongerThanTen() {
		Assertions.assertThrows(ArithmeticException.class, () -> {
			// throws exception because first name is greater than 10 characters
			Contact newContact = new Contact("455578", "definitely too long of a first name", "heff", "1234567890", "100 ave");
		});
	}
	
	@Test
	public void lastNameLongerThanTen() {
		Assertions.assertThrows(ArithmeticException.class, () -> {
			// throws exception because last name is greater than 10 characters
			Contact newContact = new Contact("455578", "first", "definitely too long of a last name", "1234567890", "100 ave");
		});
	}
	
	@Test
	public void phoneNumberMoreThanTen() {
		Assertions.assertThrows(ArithmeticException.class, () -> {
			// throws exception because phone number is greater than 10 digits
			Contact newContact = new Contact("455578", "first", "last", "12345678945670", "100 ave");
		});
	}
	
	@Test
	public void phoneNumberLessThanTen() {
		Assertions.assertThrows(ArithmeticException.class, () -> {
			// throws exception because phone number is less than 10 digits
			Contact newContact = new Contact("455578", "first", "last", "123670", "100 ave");
		});
	}
	
	@Test
	public void addressMoreThanThirtyCharacters() {
		Assertions.assertThrows(ArithmeticException.class, () -> {
			// throws exception because address is greater than 30 characters
			Contact newContact = new Contact("455578", "first", "last", "12345678945670", "100 ave in the place that is maybe a little too long");
		});
	}
	
	// test each field to make sure exception is thrown when field is null
	@Test
	public void testIdNull() {
		Assertions.assertThrows(ArithmeticException.class, () -> {
			// throws exception because id is null
			Contact newContact = new Contact(null, "first", "last", "12345678945670", "100 ave in the place that is maybe a little too long");
		});
	}
	
	@Test
	public void testFirstNull() {
		Assertions.assertThrows(ArithmeticException.class, () -> {
			// throws exception because first name is null
			Contact newContact = new Contact("45678", null, "last", "12345678945670", "100 ave in the place that is maybe a little too long");
		});
	}
	
	@Test
	public void testLastNull() {
		Assertions.assertThrows(ArithmeticException.class, () -> {
			// throws exception because last name is null
			Contact newContact = new Contact("45678", "first", null, "12345678945670", "100 ave in the place that is maybe a little too long");
		});
	}
	
	@Test
	public void testPhoneNull() {
		Assertions.assertThrows(ArithmeticException.class, () -> {
			// throws exception because last name is null
			Contact newContact = new Contact("45678", "first", "last", null, "100 ave in the place that is maybe a little too long");
		});
	}
	
	@Test
	public void testAddressNull() {
		Assertions.assertThrows(ArithmeticException.class, () -> {
			// throws exception because last name is null
			Contact newContact = new Contact("45678", "first", "last", "1234567890", null);
		});
	}
	
	// test getters and setters to ensure fields are or aren't updatable
	@Test
	public void firstNameUpdatable() {
		// create new object
		Contact newContact = new Contact("12345", "John", "Smith", "1234567890", "Random fork ave");
		// now, change the first name
		newContact.setFirstName("Ted");
		// compare actual with expected
		Assertions.assertEquals("Ted", newContact.getFirstName());
	}
	
	@Test
	public void lastNameUpdatable() {
		// create new object
		Contact newContact = new Contact("12345", "John", "Smith", "1234567890", "Random fork ave");
		// now, change the first name
		newContact.setLastName("Hoffman");
		// compare actual with expected
		Assertions.assertEquals("Hoffman", newContact.getLastName());
	}
	
	@Test
	public void phoneNumberUpdatable() {
		// create new object
		Contact newContact = new Contact("12345", "John", "Smith", "1234567890", "Random fork ave");
		// now, change the first name
		newContact.setPhoneNumber("0987654321");
		// compare actual with expected
		Assertions.assertEquals("0987654321", newContact.getPhoneNumber());
	}
	
	@Test
	public void addressUpdatable() {
		// create new object
		Contact newContact = new Contact("12345", "John", "Smith", "1234567890", "Random fork ave");
		// now, change the first name
		newContact.setUserAddress("Specific turn street");
		// compare actual with expected
		Assertions.assertEquals("Specific turn street", newContact.getUserAddress());
	}
	
	@Test
	public void idGettable() {
		// create new object
		Contact newContact = new Contact("12345", "John", "Smith", "1234567890", "Random fork ave");
		//System.out.println(newContact.getContactId());
		Assertions.assertEquals("12345", newContact.getContactId());
	}

}
