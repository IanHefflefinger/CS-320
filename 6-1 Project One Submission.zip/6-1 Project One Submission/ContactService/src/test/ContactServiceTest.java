package test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import main.ContactService;

public class ContactServiceTest {
	// ensure contact was added to contact list
	@Test // make sure contact list contains contact generated in test
	public void contactAddedSuccessfully() throws Exception {
		// size of contact list before adding new contact
		int listSize = ContactService.readContactSize();
		//System.out.println(listSize);
		// expected size of contact list after adding 1 contact
		int expectedSize = listSize + 1;
		//System.out.println(expectedSize);
		// add a contact
		ContactService.addContact();
		// size of contact list after adding 1 contact
		int actualSize = ContactService.readContactSize();
		//System.out.println(actualSize);
		// test expected equals actual
		Assertions.assertEquals(expectedSize, actualSize);
	}
	
	@Test // ensure service deletes contact as expected
	public void deleteContactSuccessfully() throws Exception {
		// create 3 contacts
		ContactService.addContact();
		ContactService.addContact();
		ContactService.addContact();
		// delete contact
		ContactService.deleteContact("2");
		// check that contacts is one less
		Assertions.assertTrue(ContactService.readContactSize() == 2);
	}
	
	@Test // check that contacts update successfully
	public void updateContactSuccessfully() throws Exception {
		// create an initial contact
		ContactService.addContact();
		// *there is only 1 contact and these are it's attributes' values: ("1"), "first", "last", "1234567890", "Random Ave");
		// update variables
		ContactService.updateContact("1", "Muffin", "Man", "8008675309", "Drury Lane");
		// test if updated
		Assertions.assertTrue(ContactService.checkUpdateSuccessful("1", "Muffin", "Man", "8008675309", "Drury Lane"));
	}
}
