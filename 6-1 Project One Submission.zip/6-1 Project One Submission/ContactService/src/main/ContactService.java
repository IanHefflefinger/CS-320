package main;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;

import java.awt.List;
import java.util.ArrayList;
import java.util.UUID;

public class ContactService {
	private static ArrayList<Contact> contacts = new ArrayList<Contact>();
	// psuedo-random string to act as object id
	private static Long count = new Long(0);
	private static String generateUniqueId() throws Exception {
		count++;
		String newId = Long.toString(count);
		if (newId.length() <= 10) {
			return newId;
		} else {
			throw new Exception("You have reached the limit");
		}
	}
	
	// add contact
	public static void addContact() throws Exception {
		Contact newContact = new Contact(generateUniqueId(), "first", "last", "1234567890", "Random Ave");
		contacts.add(newContact);
	}
	
	// read contact - used for my own visual deductions 
	/*public static void readContact(String id) {
		for (int i = 0; i < readContactSize(); i++) {
			if (contacts.get(i).getContactId().equals(id)) {
				System.out.println(contacts.get(i).getContactId());
				System.out.println(contacts.get(i).getFirstName());
				System.out.println(contacts.get(i).getLastName());
				System.out.println(contacts.get(i).getPhoneNumber());
				System.out.println(contacts.get(i).getUserAddress());
			}
		}
	} */
	
	// helper function
	public static int readContactSize() {
		return contacts.size();
	}
	
	public static void deleteContact(String id) {
		for (int i = 0; i < contacts.size(); i++) {
			if (contacts.get(i).getContactId().equals(id)) {
				contacts.remove(i);
			}
		}
	}
	
	public static void updateContact(String id, String firstName, String lastName, String phoneNumber, String userAddress) {
		for (int i = 0; i < contacts.size(); i++) {
			if (contacts.get(i).getContactId().equals(id)) {
				contacts.get(i).setFirstName(firstName);
				contacts.get(i).setLastName(lastName);
				contacts.get(i).setPhoneNumber(phoneNumber);
				contacts.get(i).setUserAddress(userAddress);
			}
		}
	}
	
	// the test class has no way to compare values for an object it has no scope into, therefore a test will be written here and the test class will just check a boolean value
	public static boolean checkUpdateSuccessful(String id, String firstName, String lastName, String phoneNumber, String userAddress) {
		boolean passed = false;
		for (int i = 0; i < contacts.size(); i++) {
			if (contacts.get(i).getContactId().equals(id) &&
				contacts.get(i).getFirstName().equals(firstName) &&
				contacts.get(i).getLastName().equals(lastName) &&
				contacts.get(i).getPhoneNumber().equals(phoneNumber) &&
				contacts.get(i).getUserAddress().equals(userAddress)) {
				passed = true;
			}
		}
		return passed;
	}
}
